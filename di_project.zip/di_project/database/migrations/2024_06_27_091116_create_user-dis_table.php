<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('user_dis', function (Blueprint $table) {
            $table->id();
            $table->integer('admission_no'); // Added the missing column
            $table->date('date_of_admission');
            $table->integer('b_id_roll_no');
            $table->string('student_name');
            $table->integer('class_applied_for');
            $table->string('section');
            $table->string('gender');
            $table->string('house');
            $table->string('student_type');
            $table->string('nationality');
            $table->string('stream_wing');
            $table->string('optional_subject');
            $table->string('reference')->nullable();
            $table->date('orientation_date');
            $table->string('branch_preference');
            
            $table->timestamps();
            
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('user-dis');
    }
};
