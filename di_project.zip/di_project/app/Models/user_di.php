<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class user_di extends Model
{
    use HasFactory;

    protected $table = 'user_dis'; // The table name

    protected $fillable = [
        'admission_no',
        'b_id_roll_no',
        'class_applied_for',
        'date_of_admission',
        'orientation_date',
        'student_name',
        'section',
        'gender',
        'house',
        'student_type',
        'nationality',
        'stream_wing',
        'optional_subject',
        'reference',
        'branch_preference',
    ];
}
