<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\user_di; // Import the model


class billing_di extends Controller
{
    public function index()
    {
        $userDis = user_di::all();
        
        // Extract admission numbers only
        $admissionNumbers = $userDis->pluck('admission_no');

        return view('auth.next-index', [
            'userDis' => $userDis,
            'admissionNumbers' => $admissionNumbers,
        ]);
    }

    public function registerUser(Request $request)
    {
        
        // Insert data into the database
        user_di::create([
            'admission_no' => $request->admissionNo,
            'b_id_roll_no' => $request->rollNo,
            'class_applied_for' => $request->classAppliedFor,
            'date_of_admission' => $request->dateOfAdmission,
            'orientation_date' => $request->orientationDate,
            'student_name' => $request->studentName,
            'section' => $request->section,
            'gender' => $request->gender,
            'house' => $request->house,
            'student_type' => $request->studentType,
            'nationality' => $request->nationality,
            'stream_wing' => $request->streamWing,
            'optional_subject' => $request->optionalSubject,
            'reference' => $request->reference,
            'branch_preference' => $request->branchPrefrence,
        ]);

        return redirect()->back()->with('success', 'User registered successfully');
    }

    public function getAdmissionData(Request $request)
    {
        $admissionNo = $request->admission_no;
        
        $userData = user_di::select([
            'student_name',
            'date_of_admission',
            'class_applied_for',
            'section',
            'gender',
            'house',
            'student_type',
            'nationality',
            'stream_wing',
            'optional_subject',
            'orientation_date',
            'branch_preference'
        ])->where('admission_no', $admissionNo)->first();
        
        if ($userData) {
            return response()->json([
                'student_name' => $userData->student_name,
                'date_of_admission' => $userData->date_of_admission,
                'class_applied_for' => $userData->class_applied_for,
                'section' => $userData->section,
                'gender' => $userData->gender,
                'house' => $userData->house,
                'student_type' => $userData->student_type,
                'nationality' => $userData->nationality,
                'stream_wing' => $userData->stream_wing,
                'optional_subject' => $userData->optional_subject,
                'orientation_date' => $userData->orientation_date,
                'branch_preference' => $userData->branch_preference,
            ]);
        } else {
            return response()->json(['error' => 'User data not found'], 404);
        }
    }
    
    







    public function editAdmissionData($admnu)
{
    $editid=$admnu;
    

    $editData = user_di::where('admission_no', $editid)->first();
    $userDis = user_di::all();
    
    
    return view('auth.next-index',compact('editData','userDis'));
}

public function deleteAdmissionData($admno)
{
//    dd($admno);
    $admissionNo = $admno;

   
    $userData = user_di::where('admission_no', $admissionNo)->delete();
    // dd($userData);
    if ($userData) {
        // Delete record
        

        return response()->json(['message' => 'Data deleted successfully']);
    } else {
        return response()->json(['error' => 'User data not found'], 404);
    }
}

}