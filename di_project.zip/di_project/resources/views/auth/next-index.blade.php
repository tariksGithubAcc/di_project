<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <style>
        body {
            font-family: Arial, sans-serif;
        }
        .sidebar {
            width: 250px;
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            background-color: #f8f9fa;
            padding-top: 20px;
        }
        .sidebar a {
            padding: 10px 15px;
            text-decoration: none;
            font-size: 18px;
            color: #000;
            display: block;
        }
        .sidebar a:hover {
            background-color: #ddd;
        }
        .content {
            margin-left: 260px;
            padding: 20px;
        }
        .form-section {
            margin-bottom: 30px;
        }
    </style>

    <title>Hello, world!</title>
  </head>
  <body>

  <div class="sidebar" style="width: 0px;">
  @if(Session::has('success'))
          <div class="alert alert-success alert-dismissible fade show border-0">{{ Session::get('success') }}</div>
        @endif

@if(Session::has('fail'))
          <div class="alert alert-danger">{{ Session::get('fail') }}</div>
        @endif
 
</div>

<div class="content">
    <div id="admissionInfo" class="form-section">
        <h2>Admission Info</h2>
        <form  method="Post" action="{{ route('register') }}">
            @csrf

            <div class="form-group">
    <label for="admissionNo">Admission No.</label>
    <select class="form-control" name="admissionNo" id="admissionNo">
        <option>--Select--</option>
        @foreach ($userDis as $user)
            <option value="{{ $user->admission_no }}">{{ $user->admission_no }}</option>
        @endforeach
    </select>
</div>

            <div class="form-group">
                <label for="dateOfAdmission">Date of Admission</label>
                <input type="date" class="form-control" name="dateOfAdmission"  id="dateOfAdmission">
            </div>
            <div class="form-group">
                <label for="rollNo">B-ID/Roll No.</label>
                <input type="text" class="form-control" name="rollNo" id="rollNo">
            </div>
            <div class="form-group">
                <label for="studentName">Student Name</label>
                <input type="text" class="form-control" name="studentName" id="studentName" <?php if(isset($editData)){?> value="{{$editData->student_name}}" <?php }?> >
            </div>
            <div class="form-group">
                <label for="classAppliedFor">Class Applied For</label>
                <select class="form-control" name="classAppliedFor" id="classAppliedFor">
                <option <?php if(isset($editData) && $editData->class_applied_for == '1') { echo "selected"; } ?> value="1">first</option>

                    <option  <?php if(isset($editData) && $editData->class_applied_for == '2') { echo "selected"; } ?> value="2">second</option>
                    <!-- Options go here -->
                </select>
            </div>
            <div class="form-group">
                <label for="section">Section</label>
                <select class="form-control" name="section" id="section">
                <option value="katrina">katrina</option>
                <option value="kareena">kareena</option>

                <option value="priyanka">priyanka</option>

                    <!-- Options go here -->
                </select>
            </div>
            <div class="form-group">
                <label for="gender">Gender</label>
                <select class="form-control" name="gender" id="gender">
                <option value="male">male</option>
                <option value="female">female</option>

                    <!-- Options go here -->
                </select>
            </div>
            <div class="form-group">
                <label for="house">House</label>
                <select class="form-control" name="house" id="house">
                <option value="bunglow">bunglow</option>
                <option value="apartment">apartment</option>

                    <!-- Options go here -->
                </select>
            </div>
            <div class="form-group">
                <label for="studentType">Student Type</label>
                <select class="form-control" name="studentType" id="studentType">
                <option value="Intelligent">Intelligent</option>
                <option value="Average">Average</option>
                    <!-- Options go here -->
                </select>
            </div>
            <div class="form-group">
                <label for="nationality">Nationality</label>
                <select class="form-control" name="nationality" id="nationality">
                <option value="Indian">Indian</option>
                <option value="Muslim">Muslim</option>
                    <!-- Options go here -->
                </select>
            </div>
            <div class="form-group">
                <label for="streamWing">Stream/Wing</label>
                <select class="form-control" name="streamWing" id="streamWing">
                <option value="first">first</option>
                <option value="second">second</option>
                    <!-- Options go here -->
                </select>
            </div>
            <div class="form-group">
                <label for="optionalSubject">Optional Subject</label>
                <select class="form-control" name="optionalSubject" id="optionalSubject">
                <option value="Hindi">Hindi</option>
                <option value="English">English</option>
                <option value="Chemistry">Chemistry</option>
                <option value="Mathematics">Mathematics</option>
                    <!-- Options go here -->
                </select>
            </div>
            <div class="form-group">
                <label for="reference">Reference (if any)</label>
                <input type="text" class="form-control" name="refrence" id="reference">
            </div>
            <div class="form-group">
                <label for="orientationDate">Orientation Date</label>
                <input type="date" class="form-control" name="orientationDate" id="orientationDate">
            </div>
            <div class="form-group">
                <label for="branchPreference">Branch Preference</label>
                <select class="form-control" name="branchPrefrence" id="branchPreference">
                <option value="Lotus">Lotus</option>
                <option value="Tulip">Tulip</option>
                <option value="Rose">Rose</option>
                <option value="Cherry">Cherry</option>
                    <!-- Options go here -->
                </select>
            </div>
            <div class="form-group">
                <label for="securityCase">Security Case</label><br>
                <input type="radio" name="securityCase" id="securityYes" value="yes" <?php if(isset($editData) && $editData->class_applied_for == 'yes') { echo "checked"; } ?> > Yes
                <input type="radio" name="securityCase" id="securityNo" value="no" checked> No
            </div>

            <button type="submit" class="btn btn-primary">Register</button>
        </form>
    </div>
    <!-- Repeat similar structure for other sections -->
</div>

<div id="userList" class="form-section">
      <h2>User List</h2>
      <table class="table table-bordered">
        <thead>
          <tr>
            <th>Admission No.</th>
            <th>Date of Admission</th>
            <th>B-ID/Roll No.</th>
            <th>Student Name</th>
            <th>Class Applied For</th>
            <th>Section</th>
            <th>Gender</th>
            <th>House</th>
            <th>Student Type</th>
            <th>Nationality</th>
            <th>Stream/Wing</th>
            <th>Optional Subject</th>
            <th>Reference</th>
            <th>Orientation Date</th>
            <th>Branch Preference</th>
          </tr>
        </thead>
        <tbody>
          @foreach ($userDis as $user)
          <!-- dd($userDis); -->
          <tr>
            <td>{{ $user->id }}</td>
            <td>{{ $user->id }}</td>
             <td>{{ $user->b_id_roll_no }}</td>
            <td>{{ $user->student_name }}</td>
             <td>{{ $user->class_applied_for }}</td>
            <td>{{ $user->section }}</td>
            <td>{{ $user->gender }}</td>
            <td>{{ $user->house }}</td>
            <td>{{ $user->student_type }}</td>
            <td>{{ $user->nationality }}</td>
            <td>{{ $user->stream_wing }}</td>
            <td>{{ $user->optional_subject }}</td>
            <td>{{ $user->reference }}</td>
            <td>{{ $user->orientation_date }}</td>
            <td>{{ $user->branch_preference }}</td>  
            <td>
            <td>
    <a href="{{ route('editAdmissionData', ['admnu' => $user->admission_no]) }}" class="btn btn-primary">Edit</a>
    <a href="{{ route('deleteAdmissionData', ['admno' => $user->admission_no]) }}" class="btn btn-danger">Delete</a>
</td>

                </td>

          </tr>
          @endforeach
        </tbody>
      </table>
    </div>


  </body>
</html>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script>
$(document).ready(function() {
    $(document).on('change', '#admissionNo', function () {
        var admission_no = $('#admissionNo').val();
        
        console.log("admission number id is " + admission_no)

        $.ajax({
            url: '{{ route('getAdmissionData') }}',
            method: 'GET',
            data: {'admission_no': admission_no},
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
            },
            success: function (response) {
                console.log("Success:", response);

                // Assuming response is an object with all fields
                $('#studentName').val(response.student_name);
                $('#dateOfAdmission').val(response.date_of_admission);
                $('#classAppliedFor').val(response.class_applied_for);
                $('#section').val(response.section);
                $('#gender').val(response.gender);
                $('#house').val(response.house);
                $('#studentType').val(response.student_type);
                $('#nationality').val(response.nationality);
                $('#streamWing').val(response.stream_wing);
                $('#optionalSubject').val(response.optional_subject);
                $('#orientationDate').val(response.orientation_date);
                $('#branchPreference').val(response.branch_preference);
            },
            error: function (xhr, status, error) {
                console.error("AJAX Error:", error);
            }
        });
    });
});

</script>


