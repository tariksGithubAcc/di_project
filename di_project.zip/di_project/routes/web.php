<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\billing_di;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('/index',[billing_di::class,'index']);
Route::any('/register-user',[billing_di::class,'registerUser'])->name('register');
// routes/web.php
Route::get('get-admission-data',[billing_di::class,'getAdmissionData'])->name('getAdmissionData');


Route::get('edit-admission-data/{admnu}', [billing_di::class, 'editAdmissionData'])->name('editAdmissionData');
Route::any('delete-admission-data/{admno}', [billing_di::class, 'deleteAdmissionData'])->name('deleteAdmissionData');